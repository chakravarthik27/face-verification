face Verification:

1.Dependenicies to be installed
opencv 2.x version
python 2.7
flask

2. Training Phase:
Train the algorithm by running create_data.py file in the terminal

3.After the data has been trained, you can execute face_recognise.py to make it run

4.Run python app.py and open your localhost where a web based interface is viewed.